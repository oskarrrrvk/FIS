package CITSIM21_02.test.java;

import CITSIM21_02.Enumeradores.TAula;
import CITSIM21_02.ModeloControlador.*;

import junit.framework.TestCase;

import java.util.ArrayList;

public class ContAulaTest extends TestCase {

    ContAula contAula;
    Aula aula;

    public void setUp() throws Exception {
        contAula = new ContAula();
        aula = new Aula("ETSISI","br0299",50,TAula.MIXTA);

    }

    public void testAgregarAula() {
        assertEquals(true, (boolean) contAula.agregarAula(aula));
        /**
        * Se guarda el aula porque ese aula no existe
        * */
    }

    public void testEliminarAula() {
        assertEquals(false, (boolean) contAula.eliminarAula(aula));
        /**
        * Se usa el false porque no se crea ningun aula por lo tanto no hay nada que eliminar
        * */
    }
}