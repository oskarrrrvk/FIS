package CITSIM21_02.test.java;

import junit.framework.TestCase;

public class UsuarioTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void testLogin() {
    }

    public void testRecuperarContrasenya() {
    }
}