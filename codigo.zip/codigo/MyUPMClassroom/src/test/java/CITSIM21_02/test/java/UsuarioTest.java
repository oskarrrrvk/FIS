package CITSIM21_02.test.java;

import CITSIM21_02.ModeloControlador.*;
import junit.framework.TestCase;

public class UsuarioTest extends TestCase {

    Usuario alumno;
    public void setUp() throws Exception {
        alumno = new Alumno("a@alumnos.upm.es","123","pepe","gonzalez","villanueva",
                "23456779D",new Perfil(new Foto("hola"),"a","H"),"12345");
    }
    public void testLogin() {
        assertEquals(true, (boolean) alumno.login("pepe","123","a@alumnos.upm.es"));
    }
    public void testLogin2() {
        assertEquals(false, (boolean) alumno.login("Juan","123","a@alumnos.upm.es"));
    }
    public void testLogin3() {
        assertEquals(false, (boolean) alumno.login("pepe","321","a@alumnos.upm.es"));
    }
    public void testLogin4() {
        assertEquals(false, (boolean) alumno.login("pepe","321","a@upm.es"));
    }

    public void testRecuperarContrasenya(){

    }
}