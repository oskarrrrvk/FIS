package CITSIM21_02.test.java;

import CITSIM21_02.Enumeradores.TCategoria;
import CITSIM21_02.ModeloControlador.*;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import servidor.UPMUsers;

public class ControladorUsuariosTest extends TestCase {

    ControladorUsuarios contUsu;
    ControladorUsuarios contUsu2;
    ControladorUsuarios contUsu3;

    Usuario usuario1;
    Usuario usuario2;
    Usuario usuario3;
    String correo1;
    String correo2;
    String correo3;
    String correo4;

    Perfil perfil;
    @Before
    public void setUp(){
        contUsu = new ControladorUsuarios();
        contUsu2 = new ControladorUsuarios();
        contUsu3 = new ControladorUsuarios();

        perfil = new Perfil(new Foto("foto"),"descripcion","H");
        correo1 = "alumno@alumnos.upm.es";
        correo2 = "pdi@upm.es";
        correo3 = "pas@upm.es";
        correo4 = "NoUPM@gmail.com";

        usuario1 = new Alumno(correo1,"1234", "Paco","apellido1","apellido2",
                "1234567F",perfil,"nx2333");
        usuario2 = new PDI(correo2,"1234","Carlos","apellido1","apellido2",
                "9876543C",perfil,"8945SV", TCategoria.CATEDRATICO);
        usuario3 = new PAS(902,1930,correo3,"1234","Adolfo",
                "apellido1","apellido2","8945SS",perfil);

        contUsu.getListaUsuarios().add(usuario1);
        contUsu2.getListaUsuarios().add(usuario2);
        contUsu3.getListaUsuarios().add(usuario3);
    }

    @Test
    public void testAltaUsuario() {
        assertEquals(null,contUsu.AltaUsuario(correo1));
        /**
         * como el usuario estaba dado de alta retorna no se pude dar de alta
         * */
    }

    public void testAltaUsuario2() {
        assertEquals(null,contUsu2.AltaUsuario(correo2));
        /**
         * como el usuario estaba dado de alta retorna no se puede dar de alta
         * */
    }

    public void testAltaUsuario3() {
        assertEquals(null,contUsu3.AltaUsuario(correo3));
        /**
         * como el usuario estaba dado de alta retorna no se puede dar de alta
         * */
    }

    public void testAltaUsuario4() {
        assertEquals(UPMUsers.PDI,contUsu.AltaUsuario(correo2));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario5() {
        assertEquals(UPMUsers.PAS,contUsu.AltaUsuario(correo3));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario6() {
        assertEquals(UPMUsers.ALUMNO,contUsu2.AltaUsuario(correo1));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario7() {
        assertEquals(UPMUsers.PAS,contUsu2.AltaUsuario(correo3));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario8() {
        assertEquals(UPMUsers.ALUMNO,contUsu3.AltaUsuario(correo1));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario9() {
        assertEquals(UPMUsers.PDI,contUsu3.AltaUsuario(correo2));
        /**
         * se puede dar de alta porque ese correo no existe
         * */
    }
    public void testAltaUsuario10() {
        assertEquals(null,contUsu.AltaUsuario(correo4));
        /**
         * no es un correo perteneciente a la UPM por lo que no se puede dar de alta
         * */
    }
}