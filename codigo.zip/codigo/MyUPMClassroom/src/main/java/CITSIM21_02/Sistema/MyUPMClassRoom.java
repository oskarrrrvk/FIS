package CITSIM21_02.Sistema;

import java.util.ArrayList;

import CITSIM21_02.ModeloControlador.ControladorUsuarios;
import CITSIM21_02.ModeloControlador.Usuario;
import CITSIM21_02.ModeloControlador.ControladorUsuarios;
import CITSIM21_02.ModeloControlador.Alumno;
import CITSIM21_02.ModeloControlador.PDI;
import CITSIM21_02.ModeloControlador.PAS;
import CITSIM21_02.Vista.GUIControladorUsuario;
import CITSIM21_02.Vista.GUIMenu;
import CITSIM21_02.Vista.GUIUsuario;
import servidor.UPMUsers;

public class MyUPMClassRoom {
    //----------------------atributos----------------------//

    private ControladorUsuarios CUsuario;
    private GUIControladorUsuario GCUsuario;
    private GUIUsuario GUsuario;
    private GUIMenu GMenu;


    //---------------------Constructor---------------------//

    public MyUPMClassRoom() {
        this.CUsuario = new ControladorUsuarios();
        this.GCUsuario = new GUIControladorUsuario();
        this.GUsuario = new GUIUsuario();
        this.GMenu = new GUIMenu();
    }

    //-----------------------Getters-----------------------//

    public ControladorUsuarios getCUsuario() {
        return this.CUsuario;
    }
    public GUIControladorUsuario getGCUsuario() {
        return this.GCUsuario;
    }
    public GUIUsuario getGUsuario() {
        return this.GUsuario;
    }
    public GUIMenu getGMenu() {
        return this.GMenu;
    }

    //-----------------------Setters-----------------------//

    public void setGCUsuario(ControladorUsuarios CUsuario) {
        this.CUsuario = CUsuario;
    }
    public void setGCUsuario(GUIControladorUsuario GCUsuario) {
        this.GCUsuario = GCUsuario;
    }
    public void setGUsuario(GUIUsuario GUsuario) {
        this.GUsuario = GUsuario;
    }
    public void setGMenu(GUIMenu GMenu) {
        this.GMenu = GMenu;
    }

    //------------------------Main------------------------//

    public static void main(String[] args)
    {

        MyUPMClassRoom app = new MyUPMClassRoom();
        int menu;
        do{
            menu = app.getGMenu().menu();
            switch (menu){
                case 1:{
                    String correo = app.getGCUsuario().introducirCorreo();
                        UPMUsers rol = app.getCUsuario().AltaUsuario(correo);
                    try{
                        switch(rol){
                            case PAS:{
                                PAS pas = app.getCUsuario().crearPAS(correo);
                                app.getGUsuario().rellenarPAS(pas);
                                app.getCUsuario().agregarUsuario(pas);
                                break;
                            }
                            case PDI:{
                                PDI pdi = app.getCUsuario().crearPDI(correo);
                                app.getGUsuario().rellenarPDI(pdi);
                                app.getCUsuario().agregarUsuario(pdi);
                                break;
                            }
                            case ALUMNO:{
                                Alumno alumno = app.getCUsuario().crearAlumno(correo);
                                app.getGUsuario().rellenarAlumno(alumno);
                                app.getCUsuario().agregarUsuario(alumno);
                                break;
                            }
                        }
                        break;
                    }catch (NullPointerException e){
                        System.out.println("   Error el correo que has introducido no es valido o ya existe");
                    }
                }
            /*case 2:{

                break;
            }
            case 3:{

                break;
            }
            case 4:{

                break;
            }*/
            }
        } while(menu!=0);
    }
}
