package Enumeradores;

public enum TAula {
    TEORIA, LABORATORIO, MIXTA
}
