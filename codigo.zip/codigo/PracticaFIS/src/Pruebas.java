import Enumeradores.TAula;
import ModeloControlador.*;

import servidor.*;
public class Pruebas {
    public static void main(String[] args)
    {
        Perfil perfil = new Perfil(new Foto("a"), "a", "a");
        Usuario usuario1= new Usuario("pepito@gmail.com", "sisis", "Pepito", "Los", "Palotes", "01234567L", perfil);
        Usuario usuario2= new Usuario("juan@gmail.com", "sisis", "Juan", "Los", "Palotes", "01234567L", perfil);
        Usuario usuario3= new Usuario("lola@gmail.com", "sisis", "Lola", "Los", "Palotes", "01234567L", perfil);
        PAS pas= new PAS(1111, 1920, usuario1);
        Observador ob1= new Observador(usuario2);
        Observador ob2= new Observador(usuario3);
        Aula aula= new Aula("Etsisi", "222", 5, TAula.MIXTA);
        Aula aul2= new Aula("Etsisi", "223", 5, TAula.MIXTA);
        pas.addAula(aula);
        pas.addAula(aul2);
        ob1.suscribirse(aula);
        ob2.suscribirse(aula);

        System.out.println(aula);

        for(Aula i:pas.getAulas())
            System.out.println(i.getIdentificadorInterno());

        for(Aula i: ob1.getAulas())
            System.out.println(i.getIdentificadorInterno());

        Autenticacion autenticacion= new Autenticacion();
        autenticacion.existeCuentaUPM("a");
    }

}
