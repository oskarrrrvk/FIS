package CITSIM21_02.Enumeradores;

public enum TAula {
    TEORIA, LABORATORIO, MIXTA
}
